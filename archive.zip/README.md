# Description

Source files for scores published by Edition Esser-Skala.


## Requirements

[EES Tools](https://github.com/edition-esser-skala/ees-tools) and their dependencies. For consistent results, use the Docker image [ees-tools](https://ghcr.io/edition-esser-skala/ees-tools).


## Further information

Consult the readme of [EES Tools](https://github.com/edition-esser-skala/ees-tools).
