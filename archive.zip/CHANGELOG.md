# Changelog

## 2.0.0 - 2021-12-23

### Changed

- uses EES Tools and new editorial guidelines


## 1.0 - 2018-01-26

### Added

- initial release
